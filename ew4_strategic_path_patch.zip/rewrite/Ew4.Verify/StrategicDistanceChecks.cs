using System;
using System.Collections.Generic;
using System.Linq;
using Ew4.Core;

// Run with: dotnet run --project rewrite/Ew4.Verify -c Release -- . --strategic-cache-only
internal static class StrategicDistanceChecks
{
    public static int Run()
    {
        int checks = 0;
        void Check(bool value, string label)
        {
            checks++;
            if (!value) throw new InvalidOperationException(label);
        }
        // Strategic path reuse must preserve all original full-map Dijkstra results.
        var strategicMap = new HexMap(13, 7);
        var strategicCells = Enumerable.Range(0, strategicMap.Count).Select(i => new MovementCell
        {
            Active = i % 19 != 0, Sea = i % 11 == 0, TerrainCost = 2 + i % 4,
            RiverEdges = (byte)(i % 3 == 0 ? 3 : 0),
            BridgeEdges = (byte)(i % 6 == 0 ? 2 : 0),
            BlockedSeaEdges = (byte)(i % 7 == 0 ? 4 : 0),
            OccupantCamp = i % 17 == 0 ? "red" : null
        }).ToArray();
        foreach (var routeActor in new[]
        {
            new MovementActor { Camp = "blue", Category = "infantry", FullBudget = 6, Remaining = 6 },
            new MovementActor { Camp = "blue", Category = "cavalry", FullBudget = 6, Remaining = 6, Transport = true },
            new MovementActor { Camp = "blue", Category = "naval", FullBudget = 6, Remaining = 6 },
            new MovementActor { Camp = "red", Category = "artillery", FullBudget = 6, Remaining = 6, Geography = true }
        })
        {
            var workspace = new Movement.StrategicDistanceCache(strategicMap, strategicCells, routeActor);
            foreach (int goal in Enumerable.Range(0, strategicMap.Count).Where(i => i % 5 == 1))
            {
                int[] endpoints = strategicMap.Within(goal, 2, includeCenter: true).OrderBy(i => i).ToArray();
                var before = Movement.DistancesTo(strategicMap, strategicCells, endpoints, routeActor);
                var after = workspace.To(endpoints);
                Check(before.Count == after.Count && before.All(p => after.TryGetValue(p.Key, out long cost) && cost == p.Value),
                    "planning-scoped strategic distances equal original unrestricted Dijkstra");
                Check(ReferenceEquals(after, workspace.To(endpoints)), "identical endpoint sets reuse strategic distance fields");
            }
        }
        var wholeMap = new HexMap(32, 1);
        var wholeCells = Enumerable.Range(0, wholeMap.Count).Select(_ => new MovementCell()).ToArray();
        var wholeActor = new MovementActor { Camp = "blue", Category = "infantry", FullBudget = 6, Remaining = 6 };
        var wholeCache = new Movement.StrategicDistanceCache(wholeMap, wholeCells, wholeActor);
        Check(wholeCache.To(new[] { 31 }).TryGetValue(0, out long wholeCost) && wholeCost == 93,
            "original strategic search remains unbounded beyond ten hexes");
        var alteredCells = wholeCells.Select((cell, i) => i == 17 ? cell with { Active = false } : cell).ToArray();
        var changedCache = new Movement.StrategicDistanceCache(wholeMap, alteredCells, wholeActor);
        Check(!changedCache.To(new[] { 31 }).ContainsKey(0),
            "new world state creates a new strategic workspace, no stale cross-command reuse");
        return checks;
    }
}
