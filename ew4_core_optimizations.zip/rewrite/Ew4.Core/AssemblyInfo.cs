using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Ew4.Verify")]

// Allow the trusted C# client to reuse the result of a validated core action.
[assembly: InternalsVisibleTo("Ew4.Client")]
