using System.Diagnostics;
using System.Globalization;
using Ew4.Core;

namespace Ew4.Client;

public sealed partial class ClientGame
{
    // Guard persists across short batch calls; a revision increment alone is
    // insufficient evidence that the battle state is making progress.
    private int aiNoChangeSteps;
    // The intermediate protocol is deliberately *not* JSON. The only full state JSON
    // is /api/action {op:"state"} after all computer factions finish or must pause.
    // Format: status|revision|url-escaped-active-faction|executed-steps|elapsed-ms
    // R = running, D = done (player owns the turn), P = event/dialogue/finished,
    // L = no measurable progress; caller must stop instead of polling forever.
    // E|url-escaped-code|url-escaped-message describes a recoverable failure.
    public string DispatchAiProgress(string body)
    {
        lock (gate)
        {
            try
            {
                if (!long.TryParse(body, NumberStyles.Integer, CultureInfo.InvariantCulture, out long expectedRevision)
                    || expectedRevision < 0)
                    throw new RuleViolation("client.ai_batch_argument", "Invalid AI state revision");
                var session = Require().Session;
                if (expectedRevision != session.Revision)
                    throw new RuleViolation("client.stale", "State changed; refresh the command");

                const int maximumSteps = 32;
                const long maximumMilliseconds = 32;
                var clock = Stopwatch.StartNew();
                int steps = 0;
                string originalFaction = session.World.ActiveFaction;
                while (steps < maximumSteps && clock.ElapsedMilliseconds < maximumMilliseconds)
                {
                    var current = Require();
                    var world = current.Session.World;
                    // No AI calculation after a modal event, a completed battle or
                    // a transition requiring the player's decision.
                    if (world.Phase != TurnPhase.Active || world.PendingDialogue != null
                        || ScenarioRules.Pending(world) != null)
                        break;
                    var active = world.Factions.Single(f => f.Id == world.ActiveFaction);
                    if (active.Human || active.Id == current.Session.PlayerFaction)
                        break;
                    var production = current.Rules.Production[active.Id];
                    var plan = WorldAi.PlanStep(world, current.Rules.Ai, production, current.Rules.Turns);
                    // Do NOT compute AiCombat previews, View(), movements, cells or
                    // units here: these were previously serialized after every step.
                    Commit(WorldAi.ExecuteStep(world, plan, current.Rules.Ai, production,
                        current.Rules.Turns, current.Rules.Battle));
                    steps++;
                    var changed = Require().Session.World;
                    if (changed.Revision <= world.Revision)
                        throw new RuleViolation("client.ai_no_progress", "AI step did not advance revision");
                    // Most valid actions replace at least one faction, cell or
                    // unit collection. A repeating RNG-only revision is suspicious.
                    bool meaningful = changed.Round != world.Round || changed.Phase != world.Phase
                        || changed.ActiveFaction != world.ActiveFaction || changed.PendingDialogue != world.PendingDialogue
                        || changed.Outcome != world.Outcome || !ReferenceEquals(changed.Units, world.Units)
                        || !ReferenceEquals(changed.Cells, world.Cells) || !ReferenceEquals(changed.Factions, world.Factions)
                        || changed.TriggeredScenarioEvents.Count != world.TriggeredScenarioEvents.Count;
                    aiNoChangeSteps = meaningful ? 0 : checked(aiNoChangeSteps + 1);
                    if (aiNoChangeSteps >= 96) break;
                    // Return immediately on each country switch so the flag can be
                    // painted before that country's actions begin.
                    if (changed.ActiveFaction != originalFaction) break;
                }
                session = Require().Session;
                var end = session.World;
                var faction = end.Factions.Single(f => f.Id == end.ActiveFaction);
                string status = end.Phase != TurnPhase.Active || end.PendingDialogue != null
                    || ScenarioRules.Pending(end) != null ? "P"
                    : faction.Human || faction.Id == session.PlayerFaction ? "D"
                    : aiNoChangeSteps >= 96 ? "L" : "R";
                if (status is "D" or "P") aiNoChangeSteps = 0;
                return string.Join('|', status, session.Revision.ToString(CultureInfo.InvariantCulture),
                    Uri.EscapeDataString(end.ActiveFaction), steps.ToString(CultureInfo.InvariantCulture),
                    clock.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture));
            }
            catch (Exception error) when (error is RuleViolation or IOException or System.Text.Json.JsonException
                or InvalidOperationException or ArgumentException or KeyNotFoundException or OverflowException)
            {
                return "E|" + Uri.EscapeDataString(error is RuleViolation rule ? rule.Code : "client.failure")
                    + "|" + Uri.EscapeDataString(error.Message);
            }
        }
    }
}
